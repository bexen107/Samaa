import { MediaCmsVjsPlugin } from './MediaCmsVjsPlugin';

export default MediaCmsVjsPlugin;
