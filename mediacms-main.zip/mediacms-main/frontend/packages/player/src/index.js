import { MediaPlayer } from './MediaPlayer';

export default MediaPlayer;
