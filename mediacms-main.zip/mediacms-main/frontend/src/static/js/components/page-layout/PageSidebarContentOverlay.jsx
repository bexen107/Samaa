import React from 'react';
import './PageSidebarContentOverlay.scss';

export const PageSidebarContentOverlay = () => <div className="page-sidebar-content-overlay"></div>;
